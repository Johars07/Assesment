from django.contrib import admin
from.models import Newsstuff

admin.site.register(Newsstuff)

# Register your models here.
